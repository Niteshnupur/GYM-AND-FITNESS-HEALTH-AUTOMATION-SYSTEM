<?php

//SELECT distinct d.time as time FROM diet d,times t WHERE d.m_id=1 order by t.id ASC
//SELECT  item,quntity FROM diet WHERE time='08:00 AM'
if(isset($_POST["id"]) && isset($_POST["date"])  && isset($_POST["excercise"]))
{
	include 'dbconfig.php';
	if ($conn->connect_error) {
    	$myObj->status="failed";
		die();
    	
	} 
	
	$id=$_POST["id"];
	$date=$_POST["date"];
	$newDate =  $date;
	$excercise=$_POST["excercise"];
	$sql="select * from sets where `m_id`=".$id." and `date`='".$date."' and e_id=".$excercise;
	$sql2="SELECT * FROM `excercise` WHERE id=".$excercise;
	if($result=$conn->query($sql)){
		if($result->num_rows <= 0){
			if($result2=$conn->query($sql2)){
				if($result2->num_rows > 0){
					$r2 = $result2->fetch_assoc();
					$myObj->status="success";
					$myObj->row=$r2;
				}
				else{
					$myObj->status="failed";
				}
			}
			else{
				$myObj->status="failed";
			}
			
		}
		else{
			$myObj->status="added";
		}
	    
	}
	
	else {
	    $myObj->status="failed";
	    
	}
	$myJSON = json_encode($myObj);
	echo $myJSON;
}
?>