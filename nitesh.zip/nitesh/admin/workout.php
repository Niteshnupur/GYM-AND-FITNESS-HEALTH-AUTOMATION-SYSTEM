<?php

//SELECT e.name,w.no_of_excercise,w.no_of_sets,w.completed_sets FROM workout w, excercise e WHERE w.m_id=1 and w.date="2018-01-04"and w.e_id=e.id"
$rows = array();
if(isset($_POST['date']) && isset($_POST['id']))
{
	include 'dbconfig.php';
	if ($conn->connect_error) {
    	$myObj->status="failed";
		$myObj->rows = $rows;
    	
	} 
	$date=$_POST['date'];
	$id=$_POST['id'];
	$newDate =  date_format(date_create_from_format('d/m/Y', $date), 'Y-m-d');
	$sql="SELECT e.name,w.no_of_excercise,w.no_of_sets,w.completed_sets FROM workout w, excercise e WHERE w.m_id=".$id." and w.date='".$newDate."'and w.e_id=e.id";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
		
    while($r = $result->fetch_assoc()) {
       $rows[] = $r;
    }
    	$myObj->status="success";
		$myObj->rows = $rows;
	} else {
	    $myObj->status="empty";
		$myObj->rows = $rows;
	}
	$myJSON = json_encode($myObj);
	echo $myJSON;
}
?>