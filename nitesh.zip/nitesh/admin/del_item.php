<?php

//SELECT distinct d.time as time FROM diet d,times t WHERE d.m_id=1 order by t.id ASC
//SELECT  item,quntity FROM diet WHERE time='08:00 AM'
if(isset($_POST["item_id"]))
{
	include 'dbconfig.php';
	if ($conn->connect_error) {
    	$myObj->status="failed";
		
    	
	} 
	
	$s_id=$_POST["item_id"];
	$sql="DELETE from diet where id=".$s_id;
	if ($conn->query($sql)) {
		$myObj->status="success";
	} 
	    	
	else {
	    $myObj->status="failed";
	    
	}
	$myJSON = json_encode($myObj);
	echo $myJSON;
}
?>