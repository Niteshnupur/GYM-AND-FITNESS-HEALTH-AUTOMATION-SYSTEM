<?php

//SELECT distinct d.time as time FROM diet d,times t WHERE d.m_id=1 order by t.id ASC
//SELECT  item,quntity FROM diet WHERE time='08:00 AM'
$meals = array();
$rows = array();
if(isset($_POST['id']))
{
	include 'dbconfig.php';
	if ($conn->connect_error) {
    	$myObj->status="failed";
		$myObj->rows = $rows;
    	
	} 
	
	$id=$_POST['id'];
	$date=$_POST['date'];
	$newDate =  date_format(date_create_from_format('d/m/Y', $date), 'Y-m-d');

	$sql_chek="SELECT enable from members where id=".$id;
	$chek=$conn->query($sql_chek);
	$chek_row=$chek->fetch_assoc();

	if($chek_row["enable"]=="true"){
		$sql="SELECT distinct m.name as meal,m.id as meal_id FROM diet d,meal m WHERE d.m_id=".$id." and d.meal_id=m.id and d.`date`='".$newDate."' order by m.id ASC";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
	    // output data of each row
			
	    while($r = $result->fetch_assoc()) {
			$meals[] = $r;
			$sql2="SELECT  * FROM diet WHERE meal_id='".$r["meal_id"]."'and m_id=".$id." and `date`='".$newDate."'";
			$result2 = $conn->query($sql2);
			if ($result2->num_rows > 0) {
				while($r2 = $result2->fetch_assoc()) {
					 $rows[] = $r2;
				}
			}
	    }
	    	$myObj->status="success";
	    	$myObj->meals = $meals;
			$myObj->rows = $rows;
			
		} else {
		    $myObj->status="empty";
			$myObj->rows = $rows;
		}
	}
	else{
		$myObj->status="disabled";
		$myObj->rows = $rows;
	}
	$myJSON = json_encode($myObj);
	echo $myJSON;
}
?>