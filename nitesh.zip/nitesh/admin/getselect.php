<?php
if(isset($_POST["id"])){
	$id=$_POST["id"];
	$rows=array();
	include 'dbconfig.php';
		if ($conn->connect_error) {
			$myObj->status="failed";
			$myObj->options= $rows;
			
		}
		$sql="SELECT DISTINCT e.name,s.e_id FROM `sets` s, `excercise` e WHERE s.`e_id`=e.`id` and s.`m_id`=".$id." ORDER BY e.`name` ASC";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
	    // output data of each row
		    while($r = $result->fetch_assoc()) {
		    	$row["name"]=$r["name"];
		    	$row["value"]=$r["e_id"];
		    	$rows[]=$row;
		    }
		    $myObj->status="success";
			$myObj->options= $rows;
		}
		else{
			$myObj->status="empty";
			$myObj->options= $rows;
		}

		$myJSON = json_encode($myObj);
		echo $myJSON;
}

?>