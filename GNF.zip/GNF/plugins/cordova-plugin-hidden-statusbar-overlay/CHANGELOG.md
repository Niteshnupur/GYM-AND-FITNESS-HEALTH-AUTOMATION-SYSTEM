## Change Log

### Version 2.0.1 (07.09.2017)
- Update package.json to work with latest cordova and NPM.

### Version 2.0.0 (11.06.2017)
- New plugin id `cordova-plugin-hidden-statusbar-overlay`
- Sample app using latest cordova.
- Updated plugin to work with latest cordova.
- Updated docs.
- Uploaded plugin to NPM.

#### Version 1.2.0 (16.03.2014)
- JS Interface to show the overlay.
- JS interface to determine if the status bar is hidden.

#### Version 1.1.0 (26.02.2014)
- JS Interface to hide the overlay if needed.

#### Version 1.0.0 (30.01.2014)
- Initial release of the plugin.