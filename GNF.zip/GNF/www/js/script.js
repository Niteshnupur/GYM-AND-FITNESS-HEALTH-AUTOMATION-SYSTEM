var w=$(window).width();
var thumb_h;
var margin_adj;
var timefun;
window.dispatchEvent(new Event('resize'));
if(w>640){
	margin_adj=80;
}
else{
	margin_adj=50;
}


console.log(w);
$(document).ready(function () {
	setMenuHeight();
	
	 document.addEventListener("backbutton", function(e){
       if(document.getElementById('home')){
       	 e.preventDefault();
       	 if($('#ham').is(':visible'))
			{
				$("#ham").slideUp("slow");
		     	$("#hb").show();
		     	$("#cb").hide();
			}
			else{
				navigator.app.exitApp();
			}
          
           
       }
       else {
           window.location.href = "home.html";
       }
    }, false);
	try {
    	if (window.cordova && window.cordova.plugins.Keyboard) {
  			window.cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
		}
	}
	catch(err) {
    	console.log("Keyboard plugin can not work");
	}

	try {
    	cordova.plugins.statusbarOverlay.hide();
	}
	catch(err) {
    	console.log("status bar plugin can not work");
	}

	try {
    	setTimeout(function() {
    		navigator.splashscreen.hide();
		}, 2000);
	}
	catch(err) {
    	console.log("splashscreen can not be use");
	}

	
	
	


});
$(window).resize(setMenuHeight);
function setMenuHeight(){
	h=$(window).height();
	thumb_h=(h-50)/3;
	$(".thumbnail").css("height", thumb_h);
	$(".menu_img").css("margin-top", (thumb_h/2)-margin_adj);
}

function share(){
	//this is the complete list of currently supported params you can pass to the plugin (all optional)
	var options = {
		  message: 'Get Fit Go', // not supported on some apps (Facebook, Instagram)
		  subject: 'Get Fit Go', 
		  url: 'http://13.233.92.226/nitesh/',
		  chooserTitle: 'Pick an app' // Android only, you can override the default share sheet title
		}

		var onSuccess = function(result) {
		  console.log("Share completed? " + result.completed); // On Android apps mostly return false even while it's true
		  console.log("Shared to app: " + result.app); // On Android result.app is currently empty. On iOS it's empty when sharing is cancelled (result.completed=false)
		}

		var onError = function(msg) {
			console.log("Sharing failed with message: " + msg);
		}

		window.plugins.socialsharing.shareWithOptions(options, onSuccess, onError);	
	//alert("zhala re");
}


function hideLoader(){
  $(".hameid-loader-overlay").fadeOut(500);
  clearTimeout(timefun);
};

function showLoader(){
	$(".connection_error").fadeOut(0);
	$(".hameid-loader-overlay").fadeIn(500);
	timefun=setTimeout(
	    function() {
	      $(".connection_error").fadeIn(500);
	    }, 8000);
};


String.prototype.capitalizeFirst = function() {
    return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase();
}


function getChat(){
	var dataString="id="+localStorage.id;
	$.ajax({
			type: "POST",
			url: "http://13.233.92.226/nitesh/admin/chat.php",
			data: dataString,
			crossDomain: true,
			cache: false,
			beforeSend: function(){},
			success: function(data){
				var JSONObject = JSON.parse(data);
				var rows=JSONObject["rows"];
				var count=JSONObject["count"]
				// console.log(JSONObject);
				if(JSONObject["status"]=="success")
				{
					localStorage.setItem('chat', JSON.stringify(rows));
					localStorage.setItem('count', count);

				}
				if(JSONObject["status"]=="failed")
				{
					console.log("failed");
				}
				if(JSONObject["status"]=="empty")
				{
					console.log("empty");
				}
				
				
			}
		});
}

function read_msg(){

	var dataString="id="+localStorage.id;
	$.ajax({
			type: "POST",
			url: "http://13.233.92.226/nitesh/admin/read_msg.php",
			data: dataString,
			crossDomain: true,
			cache: false,
			beforeSend: function(){},
			success: function(data){
				localStorage.setItem('count', 0);
			}
		});
				
}


function showChat_alert(){
	$(".chat_alert").slideDown()
	setTimeout(
	    function() {
	      $(".chat_alert").slideUp();
	    }, 3000);
}




